﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LecturerClaimSystem.Models
{
    public class Claim
    {
        [Key]
        public int Id { get; set; } // Primary Key

        // Lecturer details
        [Required]
        public string LecturerId { get; set; } // ID or Username of the Lecturer

        [Required]
        public string LecturerName { get; set; } // Name of the Lecturer

        // Claim details
        [Required]
        [Range(1, int.MaxValue, ErrorMessage = "Hours Worked must be greater than 0")]
        public int HoursWorked { get; set; }

        [Required]
        [Range(0.01, double.MaxValue, ErrorMessage = "Hourly Rate must be greater than 0")]
        public decimal HourlyRate { get; set; }

        [Required]
        [Display(Name = "Total Payment")]
        public decimal TotalPayment => HoursWorked * HourlyRate; // Auto-calculated property

        // Status tracking
        [Required]
        public string Status { get; set; } = "Pending"; // Default to Pending

        [DataType(DataType.Date)]
        public DateTime SubmittedDate { get; set; } // Automatically set on submission

        public string ReviewedBy { get; set; } // Name or ID of the reviewer
    }
}