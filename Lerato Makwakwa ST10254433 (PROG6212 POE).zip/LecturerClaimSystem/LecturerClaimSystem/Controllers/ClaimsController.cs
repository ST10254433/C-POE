﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using WebApplication3.Data; // Update to your correct namespace for ApplicationDbContext
using LecturerClaimSystem.Models;
using System.IO;
using System.Threading.Tasks;
using System.Linq;

namespace LecturerClaimSystem.Controllers
{
    public class ClaimsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ClaimsController(ApplicationDbContext context)
        {
            _context = context;
        }

        /// <summary>
        /// Displays the form to create a new claim.
        /// </summary>
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        /// <summary>
        /// Handles form submission to create a new claim.
        /// </summary>
        /// <param name="claim">The claim submitted by the user.</param>
        /// <returns>A success page if valid, or the form with errors.</returns>
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Claim claim)
        {
            if (ModelState.IsValid)
            {
                claim.SubmittedDate = DateTime.Now; // Automatically set the submission date

                // Add the new claim to the database
                _context.Claims.Add(claim);
                await _context.SaveChangesAsync();

                // Pass the submitted claim to the Success action
                return RedirectToAction(nameof(Success), new { id = claim.Id });
            }

            // Return the same form with validation errors if any
            return View(claim);
        }

        /// <summary>
        /// Displays the success confirmation page after submitting a claim.
        /// </summary>
        public async Task<IActionResult> Success(int id)
        {
            var claim = await _context.Claims.FindAsync(id);
            if (claim == null)
            {
                return NotFound(); // Handle case where the claim is not found
            }

            return View(claim); // Pass the claim data to the view
        }
    }

}




