﻿using Microsoft.AspNetCore.Mvc;
using WebApplication3.Data;
using Microsoft.EntityFrameworkCore;


namespace LecturerClaimSystem.Controllers
{
    public class HRController : Controller
    {
        private readonly ApplicationDbContext _context;

        public HRController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> ClaimsDashboard()
        {
            // Retrieve all claims from the database
            var claims = await _context.Claims.ToListAsync();

            // Pass the claims to the view
            return View(claims);
        }
    }
}

