﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LecturerClaimSystem.Migrations
{
    /// <inheritdoc />
    public partial class AddClaimModel : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

            migrationBuilder.RenameColumn(
                name: "SubmittedAt",
                table: "Claims",
                newName: "SubmittedDate");

            migrationBuilder.RenameColumn(
                name: "NumberOfHours",
                table: "Claims",
                newName: "HoursWorked");

            migrationBuilder.RenameColumn(
                name: "LecturerSurname",
                table: "Claims",
                newName: "LecturerId");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "Claims",
                newName: "ClaimId");

            migrationBuilder.AlterColumn<string>(
                name: "Status",
                table: "Claims",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "Pending",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<DateTime>(
                name: "SubmittedDate",
                table: "Claims",
                type: "datetime2",
                nullable: false,
                defaultValue: DateTime.Now);

            migrationBuilder.RenameColumn(
                name: "ReviewedBy",
                table: "Claims",
                newName: "SupportingDocument");

            migrationBuilder.RenameColumn(
                name: "LecturerId",
                table: "Claims",
                newName: "LecturerSurname");

            migrationBuilder.RenameColumn(
                name: "HoursWorked",
                table: "Claims",
                newName: "NumberOfHours");

            migrationBuilder.RenameColumn(
                name: "ClaimId",
                table: "Claims",
                newName: "Id");

            migrationBuilder.AlterColumn<string>(
                name: "Status",
                table: "Claims",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldDefaultValue: "Pending");

            migrationBuilder.AddColumn<string>(
                name: "ContactDetails",
                table: "Claims",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "Module",
                table: "Claims",
                type: "nvarchar(max)",
                nullable: true);
        }
    }
}
